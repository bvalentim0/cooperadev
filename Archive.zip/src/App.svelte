<script>
  import DoughnutMultiSeries from "./chart/DoughnutMultiSeries.svelte";
</script>

<main>
  <div class="card">
    <DoughnutMultiSeries />
  </div>
</main>